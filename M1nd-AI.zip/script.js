// ----------------------------------
// 🔑 OpenAI API Key
// ----------------------------------
const OPENAI_API_KEY = "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";

// Splash hide
setTimeout(() => {
    document.getElementById("splash").style.display = "none";
}, 2000);

// Menu toggle
document.getElementById("menuBtn").onclick = () => {
    let menu = document.getElementById("menuBox");
    menu.style.display = menu.style.display === "flex" ? "none" : "flex";
};

// Auto-grow text area upward
function autoResize() {
    const txt = document.getElementById("userInput");
    txt.style.height = "auto";
    txt.style.height = txt.scrollHeight + "px";
}

// Add message to chat
function addMessage(text, type) {
    let box = document.getElementById("chatBox");
    let div = document.createElement("div");
    div.className = "message " + type;
    div.textContent = text;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
}

// Send message
async function sendMessage() {
    let input = document.getElementById("userInput");
    let text = input.value.trim();
    if (text === "") return;

    addMessage(text, "user");
    input.value = "";
    autoResize();

    await generateAI(text);
}

// Typing effect
async function typeText(el, text) {
    el.textContent = "";
    for (let i = 0; i < text.length; i++) {
        el.textContent += text[i];
        await new Promise(r => setTimeout(r, 15));
    }
}

// -------- OPENAI FUNCTION (Correct Endpoint) ----------
async function generateAI(userMessage) {
    let box = document.getElementById("chatBox");

    let bubble = document.createElement("div");
    bubble.className = "message ai";
    bubble.textContent = "Typing...";
    box.appendChild(bubble);
    box.scrollTop = box.scrollHeight;

    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${OPENAI_API_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [
                    { role: "system", content: "You are M1nd-AI, a friendly modern smart assistant." },
                    { role: "user", content: userMessage }
                ]
            })
        });

        const data = await response.json();
        let ai = data?.choices?.[0]?.message?.content || "Error.";
        bubble.textContent = "";
        await typeText(bubble, ai);

    } catch (err) {
        bubble.textContent = "⚠ Error: Cannot connect to server.";
    }
}

// Theme
function toggleTheme() {
    document.body.classList.toggle("light");
}

// New Chat
function newChat() {
    document.getElementById("chatBox").innerHTML = "";
}

// About
function openAbout() {
    document.getElementById("aboutPopup").style.display = "flex";
}

function closeAbout() {
    document.getElementById("aboutPopup").style.display = "none";
}